# Logical model - FR LM DICOM Study Metadata - ANS IG document core v0.1.0-snapshot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Logical model - FR LM DICOM Study Metadata**

## Logical Model: Logical model - FR LM DICOM Study Metadata 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-dicom-study-metadata | *Version*:0.1.0-snapshot |
| Draft as of 2026-06-09 | *Computable Name*:FRLMDicomStudyMetadata |

 
Section Object Catalog 

**Utilisations:**

* Utilise ce/t/te Modèle logique: [Logical model - FR LM Corps document](StructureDefinition-fr-lm-corps-document.md)

Vous pouvez également vérifier [les usages dans le FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/fr-lm-dicom-study-metadata)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-fr-lm-dicom-study-metadata.csv), [Excel](StructureDefinition-fr-lm-dicom-study-metadata.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "fr-lm-dicom-study-metadata",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-dicom-study-metadata",
  "version" : "0.1.0-snapshot",
  "name" : "FRLMDicomStudyMetadata",
  "title" : "Logical model - FR LM DICOM Study Metadata",
  "status" : "draft",
  "date" : "2026-06-09T09:13:27+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Section Object Catalog",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "FRANCE"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-dicom-study-metadata",
  "baseDefinition" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-section",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "fr-lm-dicom-study-metadata",
      "path" : "fr-lm-dicom-study-metadata",
      "short" : "Logical model - FR LM DICOM Study Metadata",
      "definition" : "Section Object Catalog"
    },
    {
      "id" : "fr-lm-dicom-study-metadata.titleSection",
      "path" : "fr-lm-dicom-study-metadata.titleSection",
      "min" : 1
    },
    {
      "id" : "fr-lm-dicom-study-metadata.subSection",
      "path" : "fr-lm-dicom-study-metadata.subSection",
      "max" : "0"
    },
    {
      "id" : "fr-lm-dicom-study-metadata.entry.imagingStudy",
      "path" : "fr-lm-dicom-study-metadata.entry.imagingStudy",
      "short" : "Entrée Examen imagerie",
      "definition" : "Entrée Examen imagerie",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-imaging-study"
      }]
    }]
  }
}

```
